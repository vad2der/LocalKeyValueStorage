# challenge-one
Simple Node developer challenge.

### Goal
Clone this repo and build a simple key/value store CLI using only the core Node API. Once you have finished the challenge zip and email your solution to the email provided.

### Store API

`$ store add mykey myvalue`

`$ store list`

`$ store get mykey`

`$ store remove mykey`
